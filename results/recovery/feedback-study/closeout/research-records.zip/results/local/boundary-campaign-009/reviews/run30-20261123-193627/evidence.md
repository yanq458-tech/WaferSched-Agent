# 六个快照合计 30 分钟离线续算

单位为故障后的秒。起点取自启动前复制的断点。每份新方案均从原始故障状态完成重放。

|快照|起点区间|终点区间|状态|新方案|局部收紧|仍达到上界的分支|
|---|---|---|---|---:|---:|---:|
|blind-16-h-f1|[10.75, 15.875]|[10.75, 15.875]|UNKNOWN|0|0|19|
|blind-16-h-f2|[23.5, 24.75]|[23.5, 24.75]|UNKNOWN|0|0|19|
|blind-16-h-f3|[29.25, 31.875]|[29.25, 31.875]|UNKNOWN|0|1|18|
|blind-20-h-f2|[28.0, 93.75]|[35.75, 93.75]|UNKNOWN|4|0|22|
|blind-24-h-f1|[3.625, 64.5]|[4.125, 64.5]|UNKNOWN|2|0|26|
|blind-24-h-f2|[4.0, 56.25]|[4.875, 56.25]|UNKNOWN|2|0|26|

## blind-16-h-f1

当前最佳方案允许在 10.75 秒修复，剩余完工时间 84.5 秒，全部 16 片完成。[方案](<../../../offline-resume-008/certificates/blind-16-h-f1/schedule.json>) · [重放](<../../../offline-resume-008/certificates/blind-16-h-f1/replay-86.json>)。

仍达到全局上界的分支按末次进腔序号计数为 {28: 17, 29: 1, 30: 1}。

本轮起算上界见[既有上界记录](<../../../repair-resume-008/result.json>)。

本轮未产生可进一步排除维修刻度的分支证明。

## blind-16-h-f2

当前最佳方案允许在 23.5 秒修复，剩余完工时间 85.375 秒，全部 16 片完成。[方案](<../../steps/000049-blind-16-h-f2/witness/schedule.json>) · [重放](<../../steps/000049-blind-16-h-f2/witness/replay-188.json>)。

仍达到全局上界的分支按末次进腔序号计数为 {28: 17, 29: 1, 30: 1}。

本轮起算上界见[既有上界记录](<../../../offline-branch-compact-006/b1/blind-16-h-f2/0-gap_cuts.json>)。

本轮未产生可进一步排除维修刻度的分支证明。

## blind-16-h-f3

当前最佳方案允许在 29.25 秒修复，剩余完工时间 84.25 秒，全部 16 片完成。[方案](<../../../offline-resume-008/certificates/blind-16-h-f3/schedule.json>) · [重放](<../../../offline-resume-008/certificates/blind-16-h-f3/replay-234.json>)。

仍达到全局上界的分支按末次进腔序号计数为 {28: 16, 29: 1, 30: 1}。

本轮起算上界见[既有上界记录](<../../../offline-branch-compact-006/b1/blind-16-h-f3/0-gap_cuts.json>)。

- 步骤 176，末次进腔序号 28，晶圆 W0，路线限制 [[11, 'H1']]，此分支已排除 [29.375, 31.875] 秒（含端点）。状态 INFEASIBLE，[证据](<../../steps/000176-blind-16-h-f3/model.pb.gz>)。

## blind-20-h-f2

当前最佳方案允许在 35.75 秒修复，剩余完工时间 99.5 秒，全部 20 片完成。[方案](<../../steps/000177-blind-20-h-f2/witness/schedule.json>) · [重放](<../../steps/000177-blind-20-h-f2/witness/replay-286.json>)。

仍达到全局上界的分支按末次进腔序号计数为 {36: 20, 37: 1, 38: 1}。

本轮起算上界见[既有上界记录](<../../../offline-resume-008/b30/blind-20-h-f2/0-resume_compact.json>)。

本轮未产生可进一步排除维修刻度的分支证明。

- 步骤 93，修复 33.25 秒，[新方案](<../../steps/000093-blind-20-h-f2/witness/schedule.json>) · [重放](<../../steps/000093-blind-20-h-f2/witness/replay-266.json>)。

- 步骤 99，修复 33.5 秒，[新方案](<../../steps/000099-blind-20-h-f2/witness/schedule.json>) · [重放](<../../steps/000099-blind-20-h-f2/witness/replay-268.json>)。

- 步骤 147，修复 33.625 秒，[新方案](<../../steps/000147-blind-20-h-f2/witness/schedule.json>) · [重放](<../../steps/000147-blind-20-h-f2/witness/replay-269.json>)。

- 步骤 177，修复 35.75 秒，[新方案](<../../steps/000177-blind-20-h-f2/witness/schedule.json>) · [重放](<../../steps/000177-blind-20-h-f2/witness/replay-286.json>)。

## blind-24-h-f1

当前最佳方案允许在 4.125 秒修复，剩余完工时间 118.25 秒，全部 24 片完成。[方案](<../../steps/000148-blind-24-h-f1/witness/schedule.json>) · [重放](<../../steps/000148-blind-24-h-f1/witness/replay-33.json>)。

仍达到全局上界的分支按末次进腔序号计数为 {44: 24, 45: 1, 46: 1}。

本轮起算上界见[既有上界记录](<../../../offline-branch-compact-006/b1/blind-24-h-f1/0-gap_cuts.json>)。

本轮未产生可进一步排除维修刻度的分支证明。

- 步骤 100，修复 4.0 秒，[新方案](<../../steps/000100-blind-24-h-f1/witness/schedule.json>) · [重放](<../../steps/000100-blind-24-h-f1/witness/replay-32.json>)。

- 步骤 148，修复 4.125 秒，[新方案](<../../steps/000148-blind-24-h-f1/witness/schedule.json>) · [重放](<../../steps/000148-blind-24-h-f1/witness/replay-33.json>)。

## blind-24-h-f2

当前最佳方案允许在 4.875 秒修复，剩余完工时间 121.125 秒，全部 24 片完成。[方案](<../../steps/000149-blind-24-h-f2/witness/schedule.json>) · [重放](<../../steps/000149-blind-24-h-f2/witness/replay-39.json>)。

仍达到全局上界的分支按末次进腔序号计数为 {44: 24, 45: 1, 46: 1}。

本轮起算上界见[既有上界记录](<../../../offline-branch-compact-006/b1/blind-24-h-f2/0-gap_cuts.json>)。

本轮未产生可进一步排除维修刻度的分支证明。

- 步骤 101，修复 4.625 秒，[新方案](<../../steps/000101-blind-24-h-f2/witness/schedule.json>) · [重放](<../../steps/000101-blind-24-h-f2/witness/replay-37.json>)。

- 步骤 149，修复 4.875 秒，[新方案](<../../steps/000149-blind-24-h-f2/witness/schedule.json>) · [重放](<../../steps/000149-blind-24-h-f2/witness/replay-39.json>)。

CP-SAT 条目保存精确求解器返回状态和可重建模型。审计核对模型字节与 SHA-256。年龄流正界用整数运算复算。某个分支排除一段修复刻度后，其他分支仍可能可行。完整的前后检查点、分支身份、种子、求解耗时和收据可在本目录查阅。
