"""Audit this continuation from frozen before/after ledgers; launches no solver."""
from collections import Counter
from copy import deepcopy
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
from unittest.mock import patch

from ortools.sat.python import cp_model
from wafer_sched.recovery.feedback import boundary_campaign as campaign
from wafer_sched.recovery.feedback.route_resume import choices
from wafer_sched.recovery.feedback.resume_endpoint import age_proof
from wafer_sched.recovery.feedback.target_queries import (
    Continuation, digest, load, replay_recovery, replay_incident, terminal_domain,
)

HERE=Path(__file__).resolve().parent
BASE=HERE.parent.parent
ARCHIVE=Path("results/local/offline-resume-008")


def link(path):
    return "<"+Path(os.path.relpath(Path(path).resolve(), HERE)).as_posix()+">"


def verify_plan(case,p,h,q,path):
    plan=load(path)
    actual=min(r["place_start"] for r in plan["transfers"] if r["destination"]==p.failed_chamber)
    assert h["offset"]==0 and actual==q
    check=replay_recovery(p,q/p.scale,plan)
    assert check["valid"],check.get("errors")
    outcome=dict(witness_repair_delay_seconds=q/p.scale,makespan_seconds=plan["makespan_tick"]/p.scale)
    replay_incident(case,h,outcome,dict(verification=check))
    saved=load(path.parent/f"replay-{q}.json")
    assert saved["completed"]==outcome["completed_at"]
    assert saved["makespan"]==outcome["makespan_seconds"]
    return dict(file=str(path),sha256=digest(path),repair_seconds=q/p.scale,
                makespan=outcome["makespan_seconds"],completed=len(outcome["completed_at"]),
                replay=str(path.parent/f"replay-{q}.json"))


def verify_model(p,domain,part,lo,row):
    # Compare a freshly encoded model byte for byte; do not redo the search.
    raw=gzip.decompress(Path(row["model_file"]).read_bytes())
    assert hashlib.sha256(raw).hexdigest()==row["model_sha256"]
    class Encoded(Exception):
        pass
    def capture(model):
        assert model.proto.SerializeToString(deterministic=True)==raw
        raise Encoded()
    try:
        with patch.object(cp_model.CpSolver,"solve",side_effect=capture):
            campaign.optimize(p,domain,part,lo,0,HERE)
    except Encoded:
        return
    raise ValueError("Model capture failed")


def main():
    before,after=load(HERE/"before.json"),load(HERE/"after.json")
    count=len(before["history"])
    assert before["binding"]==after["binding"] and before["history"]==after["history"][:count]
    assert set(before["jobs"])==set(after["jobs"])
    cases={}
    for name in before["jobs"]:
        src=ARCHIVE/"inputs"/f"{name}.json"
        assert digest(src)==before["binding"][name][0]
        case=Continuation.from_dict(load(src))
        p,h=case.prepare()
        cases[name]=(case,p,h,terminal_domain(p))
    jobs=deepcopy(before["jobs"])
    witnesses,exclusions,transitions=[],[],[]
    for index,row in enumerate(after["history"][count:],count):
        name=row["case"]
        case,p,h,domain=cases[name]
        job=jobs[name]
        lo=job["lower"]
        assert row["before"]==[lo,campaign.upper(job)]
        job["turns"]+=1
        part=None
        if "rank" in row:
            matches=[n for n in job["parts"] if (n["rank"],n["job"],n["route"])==(row["rank"],row["job"],row["route"])]
            assert len(matches)==1
            part=matches[0]
            branch_domain=choices(domain,part["route"])
            old_u=part["upper"]
            if row["tool"]=="maximize_repair":
                assert (row["search_from"],row["search_to"])==(lo+1,old_u)
                assert lo<=row["branch_upper"]<=old_u
                if row["status"]=="UNKNOWN":
                    assert row["branch_upper"]==old_u
                if row["status"]=="INFEASIBLE":
                    assert row["branch_upper"]==lo
                if row["branch_upper"]<old_u:
                    verify_model(p,branch_domain,part,lo,row)
                part["upper"]=row["branch_upper"]
            elif row["tool"]=="age_flow":
                if row["status"]=="INFEASIBLE":
                    proof=load(Path(row["certificate"]))
                    assert (proof["tick"],proof["rank"],proof["index"])==(row["target"],part["rank"],part["job"])
                    age_proof(p,branch_domain,row["target"],part["rank"],part["job"],proof["quantum"],0,existing=proof)
                    assert proof["status"]=="INFEASIBLE"
                    part["upper"]=row["target"]-1
            else:
                raise ValueError(row["tool"])
            if part["upper"]<old_u:
                exclusions.append(dict(action=index,case=name,rank=part["rank"],last_wafer=(
                    domain[0][part["job"]].wafer if part["job"] is not None else None),route=part["route"],
                    method=row["tool"],status=row["status"],from_tick=part["upper"]+1,to_tick=old_u,
                    seconds=[(part["upper"]+1)/p.scale,old_u/p.scale],
                    file=row.get("model_file") or row["certificate"],scope="branch"))
            part["attempts"]+=1
            if row.get("split_into"):
                children=campaign.split(part,branch_domain)
                assert len(children)==row["split_into"]
                job["parts"].remove(part)
                job["parts"].extend(children)
        if "attained" in row:
            paths=list((BASE/"steps").glob(f"{index:06d}-{name}*/witness/schedule.json"))
            assert len(paths)==1
            q=row["after"][0]
            assert lo<q and row["attained"]<=q
            rec=verify_plan(case,p,h,q,paths[0])
            witnesses.append(dict(case=name,action=index,**rec))
            job["lower"]=q
            job["witness"]=str(paths[0].relative_to(Path.cwd()))
        job["parts"]=[n for n in job["parts"] if n["upper"]>job["lower"]]
        assert [job["lower"],campaign.upper(job)]==row["after"]
        transitions.append(dict(action=index,**row))
    assert jobs==after["jobs"]
    summary=[]
    for name,j in jobs.items():
        case,p,h,_=cases[name]
        lj=before["jobs"][name]
        hi=campaign.upper(j)
        assert digest(Path(lj["source"]))==before["binding"][name][3]
        active=[n for n in j["parts"] if n["upper"]==hi]
        w=[x for x in witnesses if x["case"]==name]
        ev=[x for x in exclusions if x["case"]==name]
        tr=[x for x in transitions if x["case"]==name]
        best=w[-1] if w else verify_plan(case,p,h,j["lower"],Path(j["witness"]))
        summary.append(dict(case=name,before=[lj["lower"]/p.scale,campaign.upper(lj)/p.scale],
            after=[j["lower"]/p.scale,hi/p.scale],status="FINITE" if j["lower"]==hi else "UNKNOWN",
            prior_upper_evidence=lj["source"],actions=len(tr),active_at_upper=len(active),active_ranks=dict(sorted(Counter(n["rank"] for n in active).items())),
            witness_count=len(w),exclusions=len(ev),best=best,tools=Counter(t["tool"]+"_"+t["status"] for t in tr)))
    log=(HERE/"run.log").read_bytes()
    content=log.decode("utf-16") if log.startswith((b"\xfe\xff",b"\xff\xfe")) else log.decode("utf-8-sig")
    epochs=[float(x) for x in re.findall(r'"elapsed_search_seconds":\s*([\d.]+)',content)]
    result=dict(before_sha256=digest(HERE/"before.json"),after_sha256=digest(HERE/"after.json"),
                initial_actions=count,new_actions=len(transitions),epoch_seconds=epochs,total_search_seconds=sum(epochs),
                cases=summary,schemes=witnesses,branch_exclusions=exclusions)
    (HERE/"audit.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf8")
    with (HERE/"cases.csv").open("w",encoding="utf-8-sig",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(["case","prior_lower_s","prior_upper_s","new_lower_s","new_upper_s","status","new_schedules","branch_exclusions","remaining_branches_at_upper","best_schedule"])
        for s in summary:
            writer.writerow([s["case"],*s["before"],*s["after"],s["status"],s["witness_count"],s["exclusions"],s["active_at_upper"],s["best"]["file"]])
    md=["# 六个快照合计 30 分钟离线续算","","单位为故障后的秒。起点取自启动前复制的断点。每份新方案均从原始故障状态完成重放。","","|快照|起点区间|终点区间|状态|新方案|局部收紧|仍达到上界的分支|","|---|---|---|---|---:|---:|---:|"]
    for s in summary:
        md.append(f"|{s['case']}|{s['before']}|{s['after']}|{s['status']}|{s['witness_count']}|{s['exclusions']}|{s['active_at_upper']}|")
    for s in summary:
        name=s["case"]
        md+=["",f"## {name}","",f"当前最佳方案允许在 {s['best']['repair_seconds']} 秒修复，剩余完工时间 {s['best']['makespan']} 秒，全部 {s['best']['completed']} 片完成。[方案]({link(s['best']['file'])}) · [重放]({link(s['best']['replay'])})。","",f"仍达到全局上界的分支按末次进腔序号计数为 {s['active_ranks']}。"]
        md+=["",f"本轮起算上界见[既有上界记录]({link(s['prior_upper_evidence'])})。"]
        if not s["exclusions"]:
            md+=["","本轮未产生可进一步排除维修刻度的分支证明。"]
        for x in witnesses:
            if x["case"]==name:
                md+=["",f"- 步骤 {x['action']}，修复 {x['repair_seconds']} 秒，[新方案]({link(x['file'])}) · [重放]({link(x['replay'])})。"]
        for x in exclusions:
            if x["case"]==name:
                md+=["",f"- 步骤 {x['action']}，末次进腔序号 {x['rank']}，晶圆 {x['last_wafer'] or '任意'}，路线限制 {x['route']}，此分支已排除 {x['seconds']} 秒（含端点）。状态 {x['status']}，[证据]({link(x['file'])})。"]
    md+=["","CP-SAT 条目保存精确求解器返回状态和可重建模型。审计核对模型字节与 SHA-256。年龄流正界用整数运算复算。某个分支排除一段修复刻度后，其他分支仍可能可行。完整的前后检查点、分支身份、种子、求解耗时和收据可在本目录查阅。"]
    (HERE/"evidence.md").write_text("\n".join(md)+"\n",encoding="utf8")
    print(json.dumps([{k:v for k,v in s.items() if k not in ("best","tools")} for s in summary],ensure_ascii=False))
    print("actions",len(transitions),"search seconds",sum(epochs),"schemes",len(witnesses),"exclusions",len(exclusions))

if __name__=="__main__":
    main()

