# 全局上界专项：六例证据索引

时间均为故障后的秒。每份新见证经原始故障快照重放。CP-SAT 记录包含重建一致的数学模型和原始求解响应；正对偶证书使用整数运算复查。

## blind-16-h-f1

[10.75, 15.875] → [10.75, 15.875]，UNKNOWN。
当前分支按最后进腔序号计数为 Counter({28: 17, 29: 1, 30: 1})。最佳修复时刻的[方案](<../offline-resume-008/certificates/blind-16-h-f1/schedule.json>)和[重放](<../offline-resume-008/certificates/blind-16-h-f1/replay-86.json>)。

固定当前见证的路线与搬运顺序，在 15.875 秒重新计算最早可行时刻，源腔取完期限冲突为 W8 超出 41 个刻度、W12 超出 41 个刻度。该诊断只针对这一顺序。

本次未进一步收紧，沿用[原上界记录](<../repair-resume-008/result.json>)。

## blind-16-h-f2

[23.5, 24.75] → [23.5, 23.875]，UNKNOWN。
当前分支按最后进腔序号计数为 Counter({28: 17, 29: 1, 30: 1})。最佳修复时刻的[方案](<../boundary-campaign-009/steps/000049-blind-16-h-f2/witness/schedule.json>)和[重放](<../boundary-campaign-009/steps/000049-blind-16-h-f2/witness/replay-188.json>)。

固定当前见证的路线与搬运顺序，在 23.875 秒重新计算最早可行时刻，源腔取完期限冲突为 W9 超出 3 个刻度。该诊断只针对这一顺序。

- 第 9 步，endpoint，排除闭区间 [24.75, 24.75]。[证据](<steps/0009-blind-16-h-f2/model.pb.gz>) · [CP-SAT 响应](<steps/0009-blind-16-h-f2/response.pb>)

- 第 28 步，endpoint，排除闭区间 [24.625, 24.625]。[证据](<steps/0028-blind-16-h-f2/model.pb.gz>) · [CP-SAT 响应](<steps/0028-blind-16-h-f2/response.pb>)

- 第 45 步，endpoint，排除闭区间 [24.0, 24.5]。[证据](<steps/0045-blind-16-h-f2/model.pb.gz>) · [CP-SAT 响应](<steps/0045-blind-16-h-f2/response.pb>)

## blind-16-h-f3

[29.25, 31.875] → [29.25, 31.875]，UNKNOWN。
当前分支按最后进腔序号计数为 Counter({28: 16, 29: 1, 30: 1})。最佳修复时刻的[方案](<../offline-resume-008/certificates/blind-16-h-f3/schedule.json>)和[重放](<../offline-resume-008/certificates/blind-16-h-f3/replay-234.json>)。

固定当前见证的路线与搬运顺序，在 31.875 秒重新计算最早可行时刻，源腔取完期限冲突为 W2 超出 21 个刻度。该诊断只针对这一顺序。

本次未进一步收紧，沿用[原上界记录](<../offline-branch-compact-006/b1/blind-16-h-f3/0-gap_cuts.json>)。

## blind-20-h-f2

[35.75, 93.75] → [35.75, 52.75]，UNKNOWN。
当前分支按最后进腔序号计数为 Counter({36: 20, 37: 1, 38: 1})。最佳修复时刻的[方案](<../boundary-campaign-009/steps/000177-blind-20-h-f2/witness/schedule.json>)和[重放](<../boundary-campaign-009/steps/000177-blind-20-h-f2/witness/replay-286.json>)。

固定当前见证的路线与搬运顺序，在 52.75 秒重新计算最早可行时刻，源腔取完期限冲突为 W17 超出 136 个刻度、W3 超出 88 个刻度、W11 超出 64 个刻度、W18 超出 41 个刻度、W9 超出 21 个刻度。该诊断只针对这一顺序。

- 第 16 步，projection_max，排除闭区间 [52.875, 93.75]。[证据](<steps/0016-blind-20-h-f2/model.pb.gz>) · [CP-SAT 响应](<steps/0016-blind-20-h-f2/response.pb>)

## blind-24-h-f1

[4.125, 64.5] → [4.125, 32.5]，UNKNOWN。
当前分支按最后进腔序号计数为 Counter({44: 24, 45: 1, 46: 1})。最佳修复时刻的[方案](<../boundary-campaign-009/steps/000148-blind-24-h-f1/witness/schedule.json>)和[重放](<../boundary-campaign-009/steps/000148-blind-24-h-f1/witness/replay-33.json>)。

固定当前见证的路线与搬运顺序，在 32.5 秒重新计算最早可行时刻，源腔取完期限冲突为 W1 超出 227 个刻度、W2 超出 214 个刻度、W8 超出 156 个刻度、W21 超出 136 个刻度、W14 超出 70 个刻度、W13 超出 44 个刻度、W19 超出 21 个刻度。该诊断只针对这一顺序。

- 第 15 步，projection_max，排除闭区间 [32.625, 64.5]。[证据](<steps/0015-blind-24-h-f1/model.pb.gz>) · [CP-SAT 响应](<steps/0015-blind-24-h-f1/response.pb>)

## blind-24-h-f2

[4.875, 56.25] → [4.875, 30.0]，UNKNOWN。
当前分支按最后进腔序号计数为 Counter({44: 24, 45: 1, 46: 1})。最佳修复时刻的[方案](<../boundary-campaign-009/steps/000149-blind-24-h-f2/witness/schedule.json>)和[重放](<../boundary-campaign-009/steps/000149-blind-24-h-f2/witness/replay-39.json>)。

固定当前见证的路线与搬运顺序，在 30.0 秒重新计算最早可行时刻，源腔取完期限冲突为 W16 超出 201 个刻度、W18 超出 182 个刻度、W17 超出 163 个刻度、W11 超出 88 个刻度、W9 超出 57 个刻度、W5 超出 18 个刻度。该诊断只针对这一顺序。

- 第 13 步，projection_max，排除闭区间 [32.625, 56.25]。[证据](<steps/0013-blind-24-h-f2/model.pb.gz>) · [CP-SAT 响应](<steps/0013-blind-24-h-f2/response.pb>)

- 第 70 步，projection_max，排除闭区间 [30.125, 32.5]。[证据](<steps/0070-blind-24-h-f2/model.pb.gz>) · [CP-SAT 响应](<steps/0070-blind-24-h-f2/response.pb>)
