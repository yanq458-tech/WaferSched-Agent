from pathlib import Path
from time import perf_counter
from unittest.mock import patch
import csv,json
from ortools.sat.python import cp_model
from wafer_sched.recovery.feedback import boundary_campaign as c
here=Path(__file__).parent
rows=list(csv.DictReader((here/'prior-unknown.csv').open()))
results=[]
for name in ('blind-16-h-f2','blind-16-h-f3'):
    data=[r for r in rows if r['case']==name]
    for category in ('zero','searched'):
        row=next(r for r in data if (int(r['branches'])==0)==(category=='zero') and float(r['solver'])>=4)
        case=c.Continuation.from_dict(c.load(c.ARCHIVE/'inputs'/(name+'.json')))
        p,_=case.prepare()
        domain=c.choices(c.terminal_domain(p),json.loads(row['route'].replace("'",'"')))
        node=c.node(int(row['rank']),int(row['hi']),int(row['job']))
        node['attempts']=int(row['seed'])-907
        folder=here/'diagnostic'/row['action'];folder.mkdir(parents=True,exist_ok=True)
        original=cp_model.CpSolver.solve
        def logged(s,model):
            rec['build_seconds']=perf_counter()-start
            rec['variables']=len(model.proto.variables);rec['constraints']=len(model.proto.constraints)
            s.parameters.log_search_progress=True;s.parameters.log_to_stdout=False
            s.parameters.max_time_in_seconds=float(row['solver'])
            lines=[];s.log_callback=lines.append
            status=original(s,model)
            (folder/'solver.log').write_text('\n'.join(lines),encoding='utf8')
            rec['solver_seconds']=s.wall_time;rec['status']=s.status_name(status);rec['branches']=s.num_branches
            rec['objective_bound']=s.best_objective_bound
            rec['search_marker']=[l for l in lines if 'Starting sequential search' in l or 'Starting subsolver' in l or 'Stopped after presolve' in l or 'Starting search at' in l]
            return status
        rec=dict(case=name,action=row['action'],category=category)
        start=perf_counter()
        with patch.object(cp_model.CpSolver,'solve',logged):
            c.optimize(p,domain,node,int(row['lo'])-1,perf_counter()+60,folder)
        results.append(rec)
        c.atomic(here/'sample-profiles.json',results)
        print(rec,flush=True)

